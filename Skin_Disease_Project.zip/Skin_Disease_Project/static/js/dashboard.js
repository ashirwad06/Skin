// dashboard.js
async function fetchResults() {
  try {
    const res = await fetch('/results');
    const data = await res.json();
    const container = document.getElementById('predictions');
    container.innerHTML = '';
    if (data.length === 0) {
      container.innerHTML = '<p>No predictions yet.</p>';
      return;
    }
    data.forEach(item => {
      const card = document.createElement('div');
      card.className = 'pred-card';
      card.innerHTML = `
        <div class="thumb"><img src="${item.url}" onerror="this.style.display='none'"></div>
        <div class="meta">
          <strong>${item.predicted_class}</strong>
          <p>Confidence: ${(item.confidence*100).toFixed(1)}%</p>
          <small>${new Date(item.created_at).toLocaleString()}</small>
        </div>
      `;
      container.appendChild(card);
    });
  } catch (err) {
    console.error(err);
  }
}

document.getElementById('uploadForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('imageInput');
  if (!input.files.length) {
    alert('Choose an image first.');
    return;
  }
  const form = new FormData();
  form.append('image', input.files[0]);
  const res = await fetch('/upload', { method: 'POST', body: form });
  const json = await res.json();
  const div = document.getElementById('uploadResult');
  if (json.status === 'ok' || res.ok) {
    div.innerText = `Predicted: ${json.predicted} (confidence ${(json.confidence*100).toFixed(1)}%)`;
    input.value = '';
    fetchResults(); // refresh list immediately
  } else {
    div.innerText = 'Error: ' + (json.error || json.message || 'unknown');
  }
});

fetchResults();
setInterval(fetchResults, 5000); // refresh every 5 seconds
