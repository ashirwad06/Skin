# app.py
import os
import threading
import time
import uuid
import sqlite3
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory
import tensorflow as tf
import numpy as np
import cv2

# -------- CONFIG --------
MODEL_PATH = "model/skin_disease_model.keras"   # <-- update if needed
UPLOAD_FOLDER = "uploads"
DB_PATH = "predictions.db"
ALLOWED_EXT = {"png", "jpg", "jpeg"}

# list of class labels in same order as model output
CLASS_LABELS = [
    "Acne", "Eczema", "Psoriasis", "Normal Skin",
    "Fungal Infection", "Pigmentation", "Other"
]  # replace/extend with your N classes

# ------------------------
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Load model once
print("Loading model:", MODEL_PATH)
model = tf.keras.models.load_model(MODEL_PATH)
print("Model loaded.")

# ---- SQLite helpers ----
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id TEXT PRIMARY KEY,
            filename TEXT,
            predicted_class TEXT,
            confidence REAL,
            created_at TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_prediction(fname, cls, conf):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('INSERT INTO predictions (id, filename, predicted_class, confidence, created_at) VALUES (?,?,?,?,?)',
              (str(uuid.uuid4()), fname, cls, float(conf), datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()

def get_latest_predictions(limit=50):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT filename, predicted_class, confidence, created_at FROM predictions ORDER BY created_at DESC LIMIT ?',[limit])
    rows = c.fetchall()
    conn.close()
    return [{"filename":r[0], "predicted_class":r[1], "confidence":r[2], "created_at":r[3]} for r in rows]

init_db()

# ---- Preprocess & predict utility ----
def allowed_file(filename):
    return "." in filename and filename.rsplit(".",1)[1].lower() in ALLOWED_EXT

def preprocess_image_for_model(image_path):
    # read with cv2, convert to RGB, resize to 224x224, normalize
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Unable to read image: " + image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (224, 224))
    img = img.astype("float32") / 255.0
    img = np.expand_dims(img, axis=0)
    return img

def predict_image(image_path):
    try:
        x = preprocess_image_for_model(image_path)
        preds = model.predict(x)    # shape (1, N)
        probs = preds[0]
        idx = int(np.argmax(probs))
        label = CLASS_LABELS[idx] if idx < len(CLASS_LABELS) else f"class_{idx}"
        confidence = float(probs[idx])
        return label, confidence, probs.tolist()
    except Exception as e:
        print("Prediction error:", e)
        return None, 0.0, []

# ---- Routes ----
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_file():
    if "image" not in request.files:
        return jsonify({"error":"No file part"}), 400
    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error":"No selected file"}), 400
    if file and allowed_file(file.filename):
        fname = str(uuid.uuid4()) + "_" + file.filename
        path = os.path.join(app.config["UPLOAD_FOLDER"], fname)
        file.save(path)

        # Predict immediately
        label, conf, _ = predict_image(path)
        if label:
            save_prediction(fname, label, conf)
            return jsonify({"status":"ok","filename":fname,"predicted":label,"confidence":conf})
        else:
            return jsonify({"status":"error","message":"prediction failed"}), 500
    else:
        return jsonify({"error":"Invalid file type"}), 400

@app.route("/results", methods=["GET"])
def results():
    rows = get_latest_predictions(limit=50)
    # add URL to each file
    for r in rows:
        r["url"] = "/uploads/" + r["filename"]
    return jsonify(rows)

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

# ---- Background watcher: processes any new files placed manually in uploads/ ----
def watch_uploads(interval=5):
    seen = set()
    while True:
        try:
            files = sorted(os.listdir(UPLOAD_FOLDER))
            for f in files:
                if f in seen: 
                    continue
                full = os.path.join(UPLOAD_FOLDER, f)
                if os.path.isfile(full) and allowed_file(f):
                    print("Auto-processing:", f)
                    label, conf, _ = predict_image(full)
                    if label:
                        save_prediction(f, label, conf)
                    seen.add(f)
            time.sleep(interval)
        except Exception as e:
            print("Watcher error:", e)
            time.sleep(interval)

# start background thread
watcher = threading.Thread(target=watch_uploads, daemon=True)
watcher.start()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
